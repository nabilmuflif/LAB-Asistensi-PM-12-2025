package com.example.notesapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddNoteActivity extends AppCompatActivity {
    private EditText titleEditText, descriptionEditText;
    private Button submitButton;
    private ImageView backButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        initViews();
        setupDatabase();
        setupClickListeners();
    }

    private void initViews() {
        titleEditText = findViewById(R.id.titleEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        submitButton = findViewById(R.id.submitButton);
        backButton = findViewById(R.id.backButton);
    }

    private void setupDatabase() {
        databaseHelper = new DatabaseHelper(this);
    }

    private void setupClickListeners() {
        backButton.setOnClickListener(v -> {
            if (hasUnsavedChanges()) {
                showCancelDialog();
            } else {
                finish();
            }
        });

        submitButton.setOnClickListener(v -> saveNote());
    }

    private boolean hasUnsavedChanges() {
        String currentTitle = titleEditText.getText().toString().trim();
        String currentDescription = descriptionEditText.getText().toString().trim();
        return !currentTitle.isEmpty() || !currentDescription.isEmpty();
    }

    private void showCancelDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Batal")
                .setMessage("Apakah Anda ingin membatalkan penambahan catatan? Data yang telah diisi akan hilang.")
                .setPositiveButton("YA", (dialog, which) -> finish())
                .setNegativeButton("TIDAK", null)
                .show();
    }

    private void saveNote() {
        String title = titleEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();

        if (title.isEmpty()) {
            titleEditText.setError("Judul harus diisi");
            titleEditText.requestFocus();
            return;
        }

        long result = databaseHelper.insertNote(title, description);
        if (result != -1) {
            Toast.makeText(this, "Catatan berhasil disimpan", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Gagal menyimpan catatan", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (hasUnsavedChanges()) {
            showCancelDialog();
        } else {
            super.onBackPressed();
        }
    }
}