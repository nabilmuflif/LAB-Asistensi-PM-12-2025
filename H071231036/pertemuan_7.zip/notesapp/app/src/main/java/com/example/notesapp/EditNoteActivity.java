package com.example.notesapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditNoteActivity extends AppCompatActivity {
    private EditText titleEditText, descriptionEditText;
    private Button updateButton, deleteButtonText;
    private ImageView backButton;
    private DatabaseHelper databaseHelper;
    private int noteId = -1;
    private String originalTitle = "";
    private String originalDescription = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        initViews();
        setupDatabase();
        handleIntent();
        setupClickListeners();
    }

    private void initViews() {
        titleEditText = findViewById(R.id.titleEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        updateButton = findViewById(R.id.updateButton);
        deleteButtonText = findViewById(R.id.deleteButtonText);
        backButton = findViewById(R.id.backButton);
    }

    private void setupDatabase() {
        databaseHelper = new DatabaseHelper(this);
    }

    private void handleIntent() {
        noteId = getIntent().getIntExtra("note_id", -1);
        originalTitle = getIntent().getStringExtra("note_title");
        originalDescription = getIntent().getStringExtra("note_description");

        if (originalTitle == null) originalTitle = "";
        if (originalDescription == null) originalDescription = "";

        titleEditText.setText(originalTitle);
        descriptionEditText.setText(originalDescription);
    }

    private void setupClickListeners() {
        backButton.setOnClickListener(v -> {
            if (hasUnsavedChanges()) {
                showCancelDialog();
            } else {
                finish();
            }
        });

        updateButton.setOnClickListener(v -> updateNote());

        deleteButtonText.setOnClickListener(v -> showDeleteDialog());
    }

    private boolean hasUnsavedChanges() {
        String currentTitle = titleEditText.getText().toString().trim();
        String currentDescription = descriptionEditText.getText().toString().trim();
        return !currentTitle.equals(originalTitle) || !currentDescription.equals(originalDescription);
    }

    private void showCancelDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Batal")
                .setMessage("Apakah Anda ingin membatalkan perubahan? Perubahan yang belum disimpan akan hilang.")
                .setPositiveButton("YA", (dialog, which) -> finish())
                .setNegativeButton("TIDAK", null)
                .show();
    }

    private void showDeleteDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Catatan")
                .setMessage("Apakah Anda yakin ingin menghapus catatan ini? Tindakan ini tidak dapat dibatalkan.")
                .setPositiveButton("HAPUS", (dialog, which) -> deleteNote())
                .setNegativeButton("BATAL", null)
                .show();
    }

    private void updateNote() {
        String title = titleEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();

        if (title.isEmpty()) {
            titleEditText.setError("Judul harus diisi");
            titleEditText.requestFocus();
            return;
        }

        if (noteId != -1) {
            boolean success = databaseHelper.updateNote(noteId, title, description);
            if (success) {
                Toast.makeText(this, "Catatan berhasil diperbarui", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(this, "Gagal memperbarui catatan", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void deleteNote() {
        if (noteId != -1) {
            boolean success = databaseHelper.deleteNote(noteId);
            if (success) {
                Toast.makeText(this, "Catatan berhasil dihapus", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(this, "Gagal menghapus catatan", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (hasUnsavedChanges()) {
            showCancelDialog();
        } else {
            super.onBackPressed();
        }
    }
}