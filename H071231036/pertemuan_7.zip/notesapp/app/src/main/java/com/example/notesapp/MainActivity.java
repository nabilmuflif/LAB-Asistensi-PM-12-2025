package com.example.notesapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private NotesAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<Note> notesList;
    private List<Note> filteredNotesList;
    private EditText searchEditText;
    private ImageView searchIcon, clearIcon;
    private TextView noDataTextView;
    private FloatingActionButton fabAdd;
    private boolean isSearchActive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupDatabase();
        setupRecyclerView();
        setupSearch();
        loadNotes();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        searchEditText = findViewById(R.id.searchEditText);
        searchIcon = findViewById(R.id.searchIcon);
        clearIcon = findViewById(R.id.clearIcon);
        noDataTextView = findViewById(R.id.noDataTextView);
        fabAdd = findViewById(R.id.fabAdd);

        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddNoteActivity.class);
            startActivity(intent);
        });

        searchIcon.setOnClickListener(v -> activateSearch());
        clearIcon.setOnClickListener(v -> deactivateSearch());
    }

    private void setupDatabase() {
        databaseHelper = new DatabaseHelper(this);
        notesList = new ArrayList<>();
        filteredNotesList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        adapter = new NotesAdapter(filteredNotesList, this::onNoteClick);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void setupSearch() {
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterNotes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void activateSearch() {
        isSearchActive = true;
        searchEditText.setVisibility(View.VISIBLE);
        clearIcon.setVisibility(View.VISIBLE);
        searchIcon.setVisibility(View.GONE);
        searchEditText.requestFocus();
    }

    private void deactivateSearch() {
        isSearchActive = false;
        searchEditText.setVisibility(View.GONE);
        clearIcon.setVisibility(View.GONE);
        searchIcon.setVisibility(View.VISIBLE);
        searchEditText.setText("");
        filteredNotesList.clear();
        filteredNotesList.addAll(notesList);
        adapter.notifyDataSetChanged();
        updateNoDataVisibility();
    }

    private void filterNotes(String query) {
        filteredNotesList.clear();
        if (query.isEmpty()) {
            filteredNotesList.addAll(notesList);
        } else {
            for (Note note : notesList) {
                if (note.getTitle().toLowerCase().contains(query.toLowerCase())) {
                    filteredNotesList.add(note);
                }
            }
        }
        adapter.notifyDataSetChanged();
        updateNoDataVisibility();
    }

    private void loadNotes() {
        notesList = databaseHelper.getAllNotes();
        filteredNotesList.clear();
        filteredNotesList.addAll(notesList);
        adapter.notifyDataSetChanged();
        updateNoDataVisibility();
    }

    private void updateNoDataVisibility() {
        if (filteredNotesList.isEmpty()) {
            noDataTextView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);

            if (isSearchActive && !searchEditText.getText().toString().isEmpty()) {
                noDataTextView.setText("No search results found");
            } else {
                noDataTextView.setText("No data");
            }
        } else {
            noDataTextView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void onNoteClick(Note note) {
        Intent intent = new Intent(MainActivity.this, EditNoteActivity.class); // Ubah ke EditNoteActivity
        intent.putExtra("note_id", note.getId());
        intent.putExtra("note_title", note.getTitle());
        intent.putExtra("note_description", note.getDescription());
        startActivity(intent);
    }


    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }
}