package com.example.notesapp;

public class Note {
    private int id;
    private String title;
    private String description;
    private long timestamp;
    private long updatedAt;

    public Note() {}

    public Note(int id, String title, String description, long timestamp, long updatedAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.timestamp = timestamp;
        this.updatedAt = updatedAt;
    }

    public Note(String title, String description) {
        this.title = title;
        this.description = description;
        this.timestamp = System.currentTimeMillis();
        this.updatedAt = this.timestamp;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }
}