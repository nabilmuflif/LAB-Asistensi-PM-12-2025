package com.example.tp_1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class EditProfileActivity extends Activity {

    public static final String EXTRA_NAME = "extra_name";
    public static final String EXTRA_USERNAME = "extra_username";

    private EditText editName;
    private EditText editUsername;
    private Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        editName = findViewById(R.id.editName);
        editUsername = findViewById(R.id.editUsername);
        buttonSave = findViewById(R.id.buttonSave);

        // Ambil data dari intent
        Intent intent = getIntent();
        String currentName = intent.getStringExtra(EXTRA_NAME);
        String currentUsername = intent.getStringExtra(EXTRA_USERNAME);

        editName.setText(currentName);
        editUsername.setText(currentUsername);

        // Simpan perubahan
        buttonSave.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra(EXTRA_NAME, editName.getText().toString());
            resultIntent.putExtra(EXTRA_USERNAME, editUsername.getText().toString());
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}
