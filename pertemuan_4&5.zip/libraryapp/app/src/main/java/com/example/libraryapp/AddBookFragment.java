package com.example.libraryapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.libraryapp.model.Book;
import com.example.libraryapp.util.BookData;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

public class AddBookFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText titleEditText;
    private EditText authorEditText;
    private EditText yearEditText;
    private EditText blurbEditText;
    private ImageView coverImageView;
    private Button selectImageButton;
    private Button saveButton;
    private Spinner genreSpinner;
    private EditText ratingEditText;

    private Uri selectedImageUri;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_book, container, false);

        // Initialize views
        titleEditText = view.findViewById(R.id.edit_title);
        authorEditText = view.findViewById(R.id.edit_author);
        yearEditText = view.findViewById(R.id.edit_year);
        blurbEditText = view.findViewById(R.id.edit_blurb);
        coverImageView = view.findViewById(R.id.cover_image);
        selectImageButton = view.findViewById(R.id.btn_select_image);
        saveButton = view.findViewById(R.id.btn_save);
        genreSpinner = view.findViewById(R.id.spinner_genre);
        ratingEditText = view.findViewById(R.id.edit_rating);

        // Set up genre spinner
        setupGenreSpinner();

        // Set up image selection
        selectImageButton.setOnClickListener(v -> openImagePicker());

        // Set up save button
        saveButton.setOnClickListener(v -> saveBook());

        // Set current year as default
        yearEditText.setText(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));

        return view;
    }

    private void setupGenreSpinner() {
        // Example genres for the spinner
        List<String> genres = Arrays.asList(
                "Select Genre", "Fiction", "Non-Fiction", "Fantasy", "Science Fiction",
                "Mystery", "Romance", "Thriller", "Horror", "Biography",
                "History", "Self-Help", "Business", "Children", "Young Adult",
                "Classics", "Poetry", "Drama", "Comics", "Adventure"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                getContext(),
                android.R.layout.simple_spinner_item,
                genres
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genreSpinner.setAdapter(adapter);
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            coverImageView.setImageURI(selectedImageUri);
            coverImageView.setVisibility(View.VISIBLE);
        }
    }

    private void saveBook() {
        // Validate input fields
        String title = titleEditText.getText().toString().trim();
        String author = authorEditText.getText().toString().trim();
        String yearStr = yearEditText.getText().toString().trim();
        String blurb = blurbEditText.getText().toString().trim();
        String genre = genreSpinner.getSelectedItem().toString();
        String ratingStr = ratingEditText.getText().toString().trim();

        if (title.isEmpty() || author.isEmpty() || yearStr.isEmpty() || blurb.isEmpty()) {
            Toast.makeText(getContext(), "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedImageUri == null) {
            Toast.makeText(getContext(), "Please select a cover image", Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse year and rating
        int year;
        float rating = 0.0f;

        try {
            year = Integer.parseInt(yearStr);
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Invalid year format", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ratingStr.isEmpty()) {
            try {
                rating = Float.parseFloat(ratingStr);
                if (rating < 0 || rating > 5) {
                    Toast.makeText(getContext(), "Rating must be between 0 and 5", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid rating format", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // If genre is the placeholder, set it to empty
        if (genre.equals("Select Genre")) {
            genre = "";
        }

        // Create new book
        Book newBook = new Book(
                UUID.randomUUID().toString(),
                title,
                author,
                year,
                blurb,
                selectedImageUri.toString(),
                false,  // Not favorite by default
                genre,
                rating
        );

        // Add book to data
        BookData.getInstance().addBook(newBook);

        // Show success message
        Toast.makeText(getContext(), "Book added successfully", Toast.LENGTH_SHORT).show();

        // Clear fields
        clearFields();
    }

    private void clearFields() {
        titleEditText.setText("");
        authorEditText.setText("");
        yearEditText.setText(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));
        blurbEditText.setText("");
        ratingEditText.setText("");
        genreSpinner.setSelection(0);
        coverImageView.setImageURI(null);
        coverImageView.setVisibility(View.GONE);
        selectedImageUri = null;
    }
}