package com.example.libraryapp;

import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.libraryapp.model.Book;
import com.example.libraryapp.util.BookData;

public class DetailActivity extends AppCompatActivity {

    private ImageView coverImageView;
    private TextView titleTextView;
    private TextView authorTextView;
    private TextView yearTextView;
    private TextView blurbTextView;
    private TextView genreTextView;
    private RatingBar ratingBar;
    private ImageButton favoriteButton;

    private Book currentBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);

        // Initialize views
        coverImageView = findViewById(R.id.detail_cover_image);
        titleTextView = findViewById(R.id.detail_title);
        authorTextView = findViewById(R.id.detail_author);
        yearTextView = findViewById(R.id.detail_year);
        blurbTextView = findViewById(R.id.detail_blurb);
        genreTextView = findViewById(R.id.detail_genre);
        ratingBar = findViewById(R.id.detail_rating);
        favoriteButton = findViewById(R.id.fab_like);

        // Enable back button in action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Book Details");
        }

        // Get book ID from intent
        String bookId = getIntent().getStringExtra("BOOK_ID");
        if (bookId != null) {
            // Load book details
            loadBookDetails(bookId);
        } else {
            // Handle error case
            Toast.makeText(this, "Error loading book details", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void loadBookDetails(String bookId) {
        currentBook = BookData.getInstance().getBookById(bookId);

        if (currentBook != null) {
            // Set book details
            titleTextView.setText(currentBook.getTitle());
            authorTextView.setText("By " + currentBook.getAuthor());
            yearTextView.setText("Published in " + currentBook.getPublicationYear());
            blurbTextView.setText(currentBook.getBlurb());

            // Load cover image
            try {
                Uri imageUri = Uri.parse(currentBook.getCoverImage());
                coverImageView.setImageURI(imageUri);
            } catch (Exception e) {
                // Set placeholder if image loading fails
                coverImageView.setImageResource(R.drawable.book_placeholder);
            }

            // Set genre if available
            if (currentBook.getGenre() != null && !currentBook.getGenre().isEmpty()) {
                genreTextView.setText("Genre: " + currentBook.getGenre());
                genreTextView.setVisibility(View.VISIBLE);
            } else {
                genreTextView.setVisibility(View.GONE);
            }

            // Set rating if available
            if (currentBook.getRating() > 0) {
                ratingBar.setRating(currentBook.getRating());
                ratingBar.setVisibility(View.VISIBLE);
            } else {
                ratingBar.setVisibility(View.GONE);
            }

            // Set favorite button state
            updateFavoriteButton();

            // Set favorite button click listener
            favoriteButton.setOnClickListener(v -> {
                BookData.getInstance().toggleFavorite(currentBook.getId());
                currentBook.toggleFavorite();
                updateFavoriteButton();

                // Show feedback to user
                String message = currentBook.isFavorite() ?
                        "Added to favorites" : "Removed from favorites";
                Toast.makeText(DetailActivity.this, message, Toast.LENGTH_SHORT).show();
            });
        } else {
            // Handle book not found case
            Toast.makeText(this, "Book not found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void updateFavoriteButton() {
        if (currentBook.isFavorite()) {
            favoriteButton.setImageResource(R.drawable.ic_favorite_filled);
        } else {
            favoriteButton.setImageResource(R.drawable.ic_favorite_border);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Handle back button click
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}