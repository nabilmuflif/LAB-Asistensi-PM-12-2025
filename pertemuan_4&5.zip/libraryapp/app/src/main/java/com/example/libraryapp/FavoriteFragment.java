package com.example.libraryapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.libraryapp.adapter.BookAdapter;
import com.example.libraryapp.model.Book;
import com.example.libraryapp.util.BookData;

import java.util.List;

public class FavoriteFragment extends Fragment {

    private RecyclerView recyclerView;
    private BookAdapter bookAdapter;
    private TextView emptyStateTextView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorite, container, false);

        // Initialize views
//        recyclerView = view.findViewById(R.id.recycler_view_favorites);
//        emptyStateTextView = view.findViewById(R.id.empty_state_text);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        // Initialize adapter with favorite books
        updateFavoritesList();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh the favorite books list when fragment becomes visible
        updateFavoritesList();
    }

    private void updateFavoritesList() {
        List<Book> favoriteBooks = BookData.getInstance().getFavoriteBooks();

        // Show empty state message if there are no favorites
        if (favoriteBooks.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyStateTextView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyStateTextView.setVisibility(View.GONE);

            // Initialize or update adapter
            if (bookAdapter == null) {
                bookAdapter = new BookAdapter(getContext(), favoriteBooks);
                recyclerView.setAdapter(bookAdapter);
            } else {
                bookAdapter.updateData(favoriteBooks);
            }
        }
    }
}