package com.example.libraryapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.libraryapp.adapter.BookAdapter;
import com.example.libraryapp.model.Book;
import com.example.libraryapp.util.BookData;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private BookAdapter bookAdapter;
    private SearchView searchView;
    private Spinner genreSpinner;
    private List<Book> allBooks;
    private List<String> genres;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize views
        recyclerView = view.findViewById(R.id.recycler_view);
        searchView = view.findViewById(R.id.search_view);
//        genreSpinner = view.findViewById(R.id.genre_spinner);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        // Get all books
        allBooks = BookData.getInstance().getAllBooks();

        // Initialize adapter
        bookAdapter = new BookAdapter(getContext(), allBooks);
        recyclerView.setAdapter(bookAdapter);

        // Set up search functionality
        setupSearchView();

        // Set up genre filter
        setupGenreSpinner();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh the book list when fragment becomes visible
        updateBookList();
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterBooks(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterBooks(newText);
                return true;
            }
        });
    }

    private void setupGenreSpinner() {
        // Get all genres
        genres = BookData.getInstance().getAllGenres();

        // Add "All Genres" option at the beginning
        List<String> spinnerItems = new ArrayList<>();
        spinnerItems.add("All Genres");
        spinnerItems.addAll(genres);

        // Create adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                getContext(),
                android.R.layout.simple_spinner_item,
                spinnerItems
        );
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genreSpinner.setAdapter(spinnerAdapter);

        // Set listener for genre selection
        genreSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedGenre = (String) parent.getItemAtPosition(position);
                if (selectedGenre.equals("All Genres")) {
                    // Show all books
                    bookAdapter.updateData(allBooks);
                } else {
                    // Filter by selected genre
                    List<Book> filteredBooks = BookData.getInstance().filterBooksByGenre(selectedGenre);
                    bookAdapter.updateData(filteredBooks);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void filterBooks(String query) {
        if (query == null || query.isEmpty()) {
            bookAdapter.updateData(allBooks);
        } else {
            List<Book> filteredBooks = BookData.getInstance().searchBooksByTitle(query);
            bookAdapter.updateData(filteredBooks);
        }
    }

    private void updateBookList() {
        allBooks = BookData.getInstance().getAllBooks();
        bookAdapter.updateData(allBooks);
    }
}