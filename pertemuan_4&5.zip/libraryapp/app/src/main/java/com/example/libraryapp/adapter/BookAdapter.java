package com.example.libraryapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.libraryapp.R;
import com.example.libraryapp.model.Book;
import com.example.libraryapp.DetailActivity;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private Context context;
    private List<Book> bookList;

    public BookAdapter(Context context, List<Book> bookList) {
        this.context = context;
        this.bookList = bookList;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = bookList.get(position);
        holder.titleTextView.setText(book.getTitle());
        holder.authorTextView.setText(book.getAuthor());
        holder.yearTextView.setText(String.valueOf(book.getPublicationYear()));

        // Load image from URI string
        try {
            Uri imageUri = Uri.parse(book.getCoverImage());
            holder.coverImageView.setImageURI(imageUri);
        } catch (Exception e) {
            // Set a placeholder image if loading fails
            holder.coverImageView.setImageResource(R.drawable.book_placeholder);
        }

        // Set favorite icon based on status
        if (book.isFavorite()) {
            holder.favoriteIcon.setVisibility(View.VISIBLE);
        } else {
            holder.favoriteIcon.setVisibility(View.GONE);
        }

        // Set genre if available
        if (book.getGenre() != null && !book.getGenre().isEmpty()) {
            holder.genreTextView.setText(book.getGenre());
            holder.genreTextView.setVisibility(View.VISIBLE);
        } else {
            holder.genreTextView.setVisibility(View.GONE);
        }

        // Set rating if available
        if (book.getRating() > 0) {
            holder.ratingTextView.setText(String.format("%.1f/5.0", book.getRating()));
            holder.ratingTextView.setVisibility(View.VISIBLE);
        } else {
            holder.ratingTextView.setVisibility(View.GONE);
        }

        // Set click listener to open detail activity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("BOOK_ID", book.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    // Method to update the data
    public void updateData(List<Book> newBooks) {
        this.bookList = newBooks;
        notifyDataSetChanged();
    }

    // ViewHolder class
    public static class BookViewHolder extends RecyclerView.ViewHolder {
        ImageView coverImageView;
        TextView titleTextView;
        TextView authorTextView;
        TextView yearTextView;
        TextView genreTextView;
        TextView ratingTextView;
        ImageView favoriteIcon;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            coverImageView = itemView.findViewById(R.id.book_cover);
            titleTextView = itemView.findViewById(R.id.book_title);
            authorTextView = itemView.findViewById(R.id.book_author);
            yearTextView = itemView.findViewById(R.id.book_year);
            genreTextView = itemView.findViewById(R.id.book_genre);
            ratingTextView = itemView.findViewById(R.id.book_rating);
            favoriteIcon = itemView.findViewById(R.id.favorite_icon);
        }
    }
}