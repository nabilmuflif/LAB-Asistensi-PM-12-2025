package com.example.libraryapp.model;

import java.io.Serializable;

public class Book implements Serializable {
    private String id;
    private String title;
    private String author;
    private int publicationYear;
    private String blurb;
    private String coverImage;  // URI string for the image
    private boolean isFavorite;
    private String genre;
    private float rating;

    // Constructor with main required fields
    public Book(String id, String title, String author, int publicationYear,
                String blurb, String coverImage) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.blurb = blurb;
        this.coverImage = coverImage;
        this.isFavorite = false;
        this.genre = "";
        this.rating = 0.0f;
    }

    // Full constructor with all fields
    public Book(String id, String title, String author, int publicationYear,
                String blurb, String coverImage, boolean isFavorite,
                String genre, float rating) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.blurb = blurb;
        this.coverImage = coverImage;
        this.isFavorite = isFavorite;
        this.genre = genre;
        this.rating = rating;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getBlurb() {
        return blurb;
    }

    public void setBlurb(String blurb) {
        this.blurb = blurb;
    }

    public String getCoverImage() {
        return coverImage;
    }

    public void setCoverImage(String coverImage) {
        this.coverImage = coverImage;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    // Method to toggle favorite status
    public void toggleFavorite() {
        this.isFavorite = !this.isFavorite;
    }
}