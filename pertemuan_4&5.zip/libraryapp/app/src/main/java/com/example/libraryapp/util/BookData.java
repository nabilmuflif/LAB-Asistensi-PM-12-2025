package com.example.libraryapp.util;

import android.content.Context;
import android.content.res.Resources;

import com.example.libraryapp.R;
import com.example.libraryapp.model.Book;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class BookData {
    private static BookData instance;
    private List<Book> bookList;

    private BookData() {
        bookList = new ArrayList<>();
        initializeDummyData();
    }

    public static synchronized BookData getInstance() {
        if (instance == null) {
            instance = new BookData();
        }
        return instance;
    }

    private void initializeDummyData() {
        // Create dummy book data (15 books)
        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "To Kill a Mockingbird",
                "Harper Lee",
                2023,
                "A gripping, heart-wrenching, and wholly remarkable tale of coming-of-age in a South poisoned by virulent prejudice.",
                "android.resource://com.example.libraryapp/drawable/book_cover_1",
                false,
                "Classic",
                4.8f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "1984",
                "George Orwell",
                2022,
                "A dystopian novel set in a totalitarian regime where Big Brother is always watching.",
                "android.resource://com.example.libraryapp/drawable/book_cover_2",
                false,
                "Science Fiction",
                4.7f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Pride and Prejudice",
                "Jane Austen",
                2021,
                "A romantic novel of manners that follows the character development of Elizabeth Bennet.",
                "android.resource://com.example.libraryapp/drawable/book_cover_3",
                false,
                "Romance",
                4.5f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Great Gatsby",
                "F. Scott Fitzgerald",
                2020,
                "A tragic story about the American Dream in the Roaring Twenties.",
                "android.resource://com.example.libraryapp/drawable/book_cover_4",
                false,
                "Classic",
                4.3f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Hobbit",
                "J.R.R. Tolkien",
                2019,
                "A fantasy novel about the adventures of hobbit Bilbo Baggins.",
                "android.resource://com.example.libraryapp/drawable/book_cover_5",
                false,
                "Fantasy",
                4.6f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Catcher in the Rye",
                "J.D. Salinger",
                2018,
                "A coming-of-age novel about the struggles of adolescence and identity.",
                "android.resource://com.example.libraryapp/drawable/book_cover_6",
                false,
                "Young Adult",
                4.1f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Lord of the Rings",
                "J.R.R. Tolkien",
                2017,
                "An epic high-fantasy novel about the quest to destroy the One Ring.",
                "android.resource://com.example.libraryapp/drawable/book_cover_7",
                false,
                "Fantasy",
                4.9f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Animal Farm",
                "George Orwell",
                2016,
                "An allegorical novella about a group of farm animals who rebel against their human farmer.",
                "android.resource://com.example.libraryapp/drawable/book_cover_8",
                false,
                "Political Fiction",
                4.4f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Alchemist",
                "Paulo Coelho",
                2015,
                "A philosophical story about a shepherd boy who dreams of finding a treasure.",
                "android.resource://com.example.libraryapp/drawable/book_cover_9",
                false,
                "Philosophical Fiction",
                4.2f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Brave New World",
                "Aldous Huxley",
                2014,
                "A dystopian novel set in a futuristic World State of genetically modified citizens.",
                "android.resource://com.example.libraryapp/drawable/book_cover_10",
                false,
                "Science Fiction",
                4.5f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "The Odyssey",
                "Homer",
                2013,
                "An ancient Greek epic poem about the journey of Odysseus after the Trojan War.",
                "android.resource://com.example.libraryapp/drawable/book_cover_11",
                false,
                "Epic Poetry",
                4.3f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Moby-Dick",
                "Herman Melville",
                2012,
                "A novel about the obsessive quest of Captain Ahab for revenge on the white whale.",
                "android.resource://com.example.libraryapp/drawable/book_cover_12",
                false,
                "Adventure",
                4.1f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "War and Peace",
                "Leo Tolstoy",
                2011,
                "A novel that chronicles the French invasion of Russia and the impact of the Napoleonic era on Russian society.",
                "android.resource://com.example.libraryapp/drawable/book_cover_13",
                false,
                "Historical Fiction",
                4.7f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "One Hundred Years of Solitude",
                "Gabriel García Márquez",
                2010,
                "A magical realist novel that tells the multi-generational story of the Buendía family.",
                "android.resource://com.example.libraryapp/drawable/book_cover_14",
                false,
                "Magical Realism",
                4.6f
        ));

        bookList.add(new Book(
                UUID.randomUUID().toString(),
                "Don Quixote",
                "Miguel de Cervantes",
                2009,
                "A Spanish novel about the adventures of a nobleman who sets out to revive chivalry.",
                "android.resource://com.example.libraryapp/drawable/book_cover_15",
                false,
                "Satire",
                4.4f
        ));

        // Sort books by publication year (newest first)
        sortBooksByYear();
    }

    // Get all books sorted by publication year (newest first)
    public List<Book> getAllBooks() {
        sortBooksByYear();
        return new ArrayList<>(bookList);
    }

    // Get favorite books
    public List<Book> getFavoriteBooks() {
        return bookList.stream()
                .filter(Book::isFavorite)
                .collect(Collectors.toList());
    }

    // Search books by title
    public List<Book> searchBooksByTitle(String query) {
        String lowerCaseQuery = query.toLowerCase();
        return bookList.stream()
                .filter(book -> book.getTitle().toLowerCase().contains(lowerCaseQuery))
                .collect(Collectors.toList());
    }

    // Filter books by genre
    public List<Book> filterBooksByGenre(String genre) {
        return bookList.stream()
                .filter(book -> book.getGenre().equals(genre))
                .collect(Collectors.toList());
    }

    // Get all available genres
    public List<String> getAllGenres() {
        return bookList.stream()
                .map(Book::getGenre)
                .distinct()
                .collect(Collectors.toList());
    }

    // Add a new book
    public void addBook(Book book) {
        bookList.add(book);
        sortBooksByYear();
    }

    // Update existing book
    public void updateBook(Book updatedBook) {
        for (int i = 0; i < bookList.size(); i++) {
            if (bookList.get(i).getId().equals(updatedBook.getId())) {
                bookList.set(i, updatedBook);
                return;
            }
        }
    }

    // Get book by ID
    public Book getBookById(String bookId) {
        for (Book book : bookList) {
            if (book.getId().equals(bookId)) {
                return book;
            }
        }
        return null;
    }

    // Toggle favorite status
    public void toggleFavorite(String bookId) {
        Book book = getBookById(bookId);
        if (book != null) {
            book.toggleFavorite();
        }
    }

    // Sort books by publication year (newest first)
    private void sortBooksByYear() {
        Collections.sort(bookList, (b1, b2) -> Integer.compare(b2.getPublicationYear(), b1.getPublicationYear()));
    }
}