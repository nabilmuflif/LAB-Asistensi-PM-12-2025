package com.example.myapplication;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CharacterDetailFragment extends Fragment {
    private static final String ARG_USER = "user";
    private User user;
    private ImageView imageViewCharacter;
    private TextView textViewName, textViewStatus, textViewSpecies, textViewGender;
    private ProgressBar detailProgressBar;
    private CardView detailCardView;
    private LinearLayout errorLayout;
    private ImageButton reloadButton;

    // Thread handling
    private ExecutorService executor;
    private Handler handler;

    public static CharacterDetailFragment newInstance(User user) {
        CharacterDetailFragment fragment = new CharacterDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER, user);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            user = (User) getArguments().getSerializable(ARG_USER);
        }

        // Inisialisasi executor dan handler
        executor = Executors.newSingleThreadExecutor();
        handler = new Handler(Looper.getMainLooper());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_character_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Setup komponen UI
        imageViewCharacter = view.findViewById(R.id.imageViewCharacter);
        textViewName = view.findViewById(R.id.textViewName);
        textViewStatus = view.findViewById(R.id.textViewStatus);
        textViewSpecies = view.findViewById(R.id.textViewSpecies);
        textViewGender = view.findViewById(R.id.textViewGender);
        detailProgressBar = view.findViewById(R.id.detailProgressBar);
        detailCardView = view.findViewById(R.id.detailCardView);
        errorLayout = view.findViewById(R.id.errorLayout);
        reloadButton = view.findViewById(R.id.reloadButton);

        // Setup reload button click listener
        reloadButton.setOnClickListener(v -> loadCharacterData());

        // Initial UI state
        detailProgressBar.setVisibility(View.VISIBLE);
        detailCardView.setVisibility(View.GONE);
        errorLayout.setVisibility(View.GONE);

        loadCharacterData();
    }

    private void loadCharacterData() {
        // Reset UI state before loading
        detailProgressBar.setVisibility(View.VISIBLE);
        detailCardView.setVisibility(View.GONE);
        errorLayout.setVisibility(View.GONE);

        if (user == null) {
            showError();
            return;
        }

        // Check internet connection first
        if (!isNetworkAvailable()) {
            showError();
            return;
        }

        // Muat data di background thread menggunakan ExecutorService
        executor.execute(() -> {
            try {
                // Simulasi waktu pemrosesan
                Thread.sleep(800);

                // Update UI pada main thread menggunakan Handler
                handler.post(() -> {
                    // Set data teks
                    textViewName.setText(user.getName());
                    textViewStatus.setText("Status: " + user.getStatus());
                    textViewSpecies.setText("Species: " + user.getSpecies());
                    textViewGender.setText("Gender: " + user.getGender());

                    // Muat gambar dengan Picasso (sudah menangani background threading)
                    Picasso.get()
                            .load(user.getImage())
                            .into(imageViewCharacter, new Callback() {
                                @Override
                                public void onSuccess() {
                                    // Sembunyikan progress bar dan tampilkan konten ketika gambar selesai dimuat
                                    detailProgressBar.setVisibility(View.GONE);
                                    detailCardView.setVisibility(View.VISIBLE);
                                }

                                @Override
                                public void onError(Exception e) {
                                    showError();
                                }
                            });
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
                handler.post(this::showError);
            }
        });
    }

    private void showError() {
        // Hide progress bar and content, show error message
        detailProgressBar.setVisibility(View.GONE);
        detailCardView.setVisibility(View.GONE);
        errorLayout.setVisibility(View.VISIBLE);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager)
                requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return false;
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            Network network = connectivityManager.getActiveNetwork();
            if (network == null) {
                return false;
            }

            NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);
            return capabilities != null && (
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        } else {
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            return networkInfo != null && networkInfo.isConnected();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (executor != null) {
            executor.shutdown();
        }
    }
}