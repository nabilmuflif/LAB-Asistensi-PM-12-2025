package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements
        UserAdapter.OnItemClickListener,
        UserAdapter.OnLoadMoreClickListener {

    private ApiService apiService;
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private int currentPage = 1;
    private boolean isLoading = false;
    private ProgressBar detailProgressBar;
    private LinearLayout errorLayout;
    private List<User> allCharacters = new ArrayList<>();

    // Thread handling
    private ExecutorService executor;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi executor dan handler
        executor = Executors.newSingleThreadExecutor();
        handler = new Handler(Looper.getMainLooper());

        apiService = RetrofitClient.getClient().create(ApiService.class);
        recyclerView = findViewById(R.id.recyclerView);
        detailProgressBar = findViewById(R.id.detailProgressBar);
        errorLayout = findViewById(R.id.errorLayout);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        userAdapter = new UserAdapter(allCharacters, this, this);
        recyclerView.setAdapter(userAdapter);

        findViewById(R.id.reloadButton).setOnClickListener(v -> {
            currentPage = 1;
            allCharacters.clear();
            loadCharacters(currentPage);
        });

        loadCharacters(currentPage);

    }

    // Implementasi onLoadMoreClick dari interface baru
    @Override
    public void onLoadMoreClick() {
        if (!isLoading) {
            // Cek koneksi internet terlebih dahulu
            if (!isNetworkAvailable()) {
                // Jika tidak ada internet, sembunyikan tombol load more saja
                userAdapter.setShowLoadMoreButton(false);
                Toast.makeText(MainActivity.this, "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show();
                return;
            }

            // Jika ada internet, lanjutkan load data
            currentPage++;
            loadCharacters(currentPage);
        }
    }

    private void loadCharacters(int page) {
        isLoading = true;
        detailProgressBar.setVisibility(View.VISIBLE);
        errorLayout.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);

        // Hanya tampilkan error layout dan sembunyikan RecyclerView
        // pada halaman pertama (initial load)
        if (page == 1) {
            errorLayout.setVisibility(View.GONE);
        }

        // Check internet connection first
        if (!isNetworkAvailable()) {
            if (page == 1) {
                // Jika halaman pertama, tampilkan error
                showError();
            } else {
                // Jika bukan halaman pertama, jangan sembunyikan RecyclerView
                detailProgressBar.setVisibility(View.GONE);
                userAdapter.setShowLoadMoreButton(false);
                Toast.makeText(MainActivity.this, "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show();
            }
            isLoading = false;
            return;
        }

        executor.execute(() -> {
            try {
                // Buat objek Call
                Call<UserResponse> call = apiService.getUsers(page);

                // Simulasi waktu loading
                Thread.sleep(800);

                // Eksekusi call secara sinkron di thread background
                Response<UserResponse> response = call.execute();

                // Pindah ke thread UI untuk update tampilan
                handler.post(() -> {
                    isLoading = false;

                    if (response.isSuccessful()) {
                        detailProgressBar.setVisibility(View.GONE);
                        errorLayout.setVisibility(View.GONE);
                        List<User> newCharacters = response.body().getResults();

                        // Cek apakah tidak ada halaman lagi
                        UserResponse.Info info = response.body().getInfo();
                        if (info != null && info.getNext() == null) {
                            userAdapter.setShowLoadMoreButton(false); // Sembunyikan tombol load more
                            Toast.makeText(MainActivity.this, "Tidak ada karakter lagi", Toast.LENGTH_SHORT).show();
                        } else {
                            // Pastikan tombol load more aktif saat ada data
                            userAdapter.setShowLoadMoreButton(true);
                        }

                        if (newCharacters != null) {
                            allCharacters.addAll(newCharacters);
                            userAdapter.notifyDataSetChanged();
                        }
                    } else {
                        errorLayout.setVisibility(View.VISIBLE);
                        detailProgressBar.setVisibility(View.GONE);
                        Log.e("MainActivity", "Error: " + response.code());
                        Toast.makeText(MainActivity.this, "Error memuat karakter", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (InterruptedException e) {
                Log.e("MainActivity", "Thread interrupted: " + e.getMessage());
                handler.post(() -> {
                    isLoading = false;
                    showError();
                    Toast.makeText(MainActivity.this, "Loading dibatalkan", Toast.LENGTH_SHORT).show();
                });
            } catch (IOException e) {
                Log.e("MainActivity", "Network error: " + e.getMessage());
                handler.post(() -> {
                    isLoading = false;
                    showError();
                    Toast.makeText(MainActivity.this, "Error jaringan", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @Override
    public void onItemClick(User user) {
        // Periksa koneksi internet sebelum menampilkan fragment detail
//        if (!isNetworkAvailable()) {
//            Toast.makeText(this, "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show();
//            return;
//        }

        // Menampilkan fragment detail karakter
        CharacterDetailFragment fragment = CharacterDetailFragment.newInstance(user);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.main, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void showError() {
        Log.d("MainActivity", "showError dipanggil");
        detailProgressBar.setVisibility(View.GONE);
        errorLayout.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);

        // Force layout refresh
        errorLayout.invalidate();
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            return false;
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            Network network = connectivityManager.getActiveNetwork();
            if (network == null) {
                return false;
            }

            NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);
            return capabilities != null && (
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        } else {
            // Untuk API level lebih rendah
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            return networkInfo != null && networkInfo.isConnected();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Matikan executor ketika activity dihancurkan
        if (executor != null) {
            executor.shutdown();
        }
    }


}