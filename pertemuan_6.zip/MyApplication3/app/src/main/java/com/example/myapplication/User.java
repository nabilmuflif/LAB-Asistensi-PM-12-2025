package com.example.myapplication;

import java.io.Serializable;

public class User implements Serializable {
    private int id;
    private String name;
    private String status;
    private String species;
    private String gender;
    private String image;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getGender() {
        return gender;
    }

    public void setGender() {
        this.gender = gender;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    // Menyediakan metode untuk backwards compatibility dengan UserAdapter
    public String getFirst_name() {
        return name;
    }

    public String getLast_name() {
        return "";
    }

    public String getEmail() {
        return species + " - " + status;
    }

    public String getAvatar() {
        return image;
    }
}