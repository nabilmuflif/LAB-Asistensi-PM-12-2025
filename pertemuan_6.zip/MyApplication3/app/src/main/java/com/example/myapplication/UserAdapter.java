package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_USER = 0;
    private static final int VIEW_TYPE_LOAD_MORE = 1;
    private List<User> userList;
    private OnItemClickListener listener;
    private OnLoadMoreClickListener loadMoreListener;
    private boolean showLoadMoreButton = false;

    public interface OnItemClickListener {
        void onItemClick(User user);
    }

    public interface OnLoadMoreClickListener {
        void onLoadMoreClick();
    }

    public UserAdapter(List<User> userList, OnItemClickListener listener, OnLoadMoreClickListener loadMoreListener) {
        this.userList = userList;
        this.listener = listener;
        this.loadMoreListener = loadMoreListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_USER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item, parent, false);
            return new UserViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.load_more_button, parent, false);
            return new LoadMoreViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof UserViewHolder) {
            User user = userList.get(position);
            ((UserViewHolder) holder).bind(user, listener);
        } else if (holder instanceof LoadMoreViewHolder) {
            ((LoadMoreViewHolder) holder).bind(loadMoreListener);
        }
    }

    @Override
    public int getItemCount() {
        // Jika tidak ada data, tidak perlu menambahkan apa-apa
        if (userList == null || userList.isEmpty()) {
            return 0;
        }
        // Jika ada data, tambahkan tombol Load More jika diaktifkan
        return showLoadMoreButton ? userList.size() + 1 : userList.size();
    }

    @Override
    public int getItemViewType(int position) {
        // Tombol Load More hanya di posisi terakhir
        return (position == userList.size()) ? VIEW_TYPE_LOAD_MORE : VIEW_TYPE_USER;
    }

    public void setShowLoadMoreButton(boolean show) {
        this.showLoadMoreButton = show;
        notifyDataSetChanged();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        private ImageView avatarImageView;
        private TextView nameTextView;
        private TextView emailTextView;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            avatarImageView = itemView.findViewById(R.id.avatarImageView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            emailTextView = itemView.findViewById(R.id.emailTextView);
        }

        public void bind(final User user, final OnItemClickListener listener) {
            Picasso.get().load(user.getImage()).into(avatarImageView);
            nameTextView.setText(user.getName());
            emailTextView.setText(user.getSpecies());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onItemClick(user);
                    }
                }
            });
        }
    }

    public static class LoadMoreViewHolder extends RecyclerView.ViewHolder {
        private Button loadMoreButton;

        public LoadMoreViewHolder(@NonNull View itemView) {
            super(itemView);
            loadMoreButton = itemView.findViewById(R.id.loadMoreButton);
        }

        public void bind(final OnLoadMoreClickListener listener) {
            loadMoreButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        listener.onLoadMoreClick();
                    }
                }
            });
        }
    }
}